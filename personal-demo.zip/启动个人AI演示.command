#!/bin/zsh
task_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
task_python="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3"
if [[ ! -x "$task_python" ]]; then
  task_python="$(command -v python3)"
fi
if [[ -z "$task_python" ]]; then
  print '未找到Python 3。请安装官方Python 3后，重新双击本文件。无需安装其他依赖。'
  read 'task_answer?按回车退出。'
  exit 1
fi
print '正在启动上岸本机助手v2；请保留此终端窗口。'
"$task_python" "$task_dir/demo_server.py" "$@"
task_exit=$?
if [[ $task_exit -ne 0 ]]; then
  print '助手未能启动。请确认已完整解压，保留上方错误信息，不要直接打开旧的127.0.0.1地址。'
  read 'task_answer?按回车退出。'
fi
exit $task_exit
