"""Local-only, dependency-free connector for the single-file interview demo.

No API key is stored here. The browser supplies it per request. The connector
relays only the fixed free model to the official provider, without request logs.
"""
import argparse
import json
from pathlib import Path
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import urllib.error
import urllib.request
import webbrowser

ENDPOINT = 'https://open.bigmodel.cn/api/paas/v4/chat/completions'
MODEL = 'glm-4.7-flash'


def validate_payload(value):
    allowed = {'model', 'messages', 'thinking', 'response_format', 'temperature', 'max_tokens', 'stream'}
    if not isinstance(value, dict) or set(value) - allowed or value.get('model') != MODEL or value.get('stream') is not False:
        raise ValueError('只允许固定的免费文字模型，不允许工具或其他接口。')
    if not isinstance(value.get('max_tokens'), int) or not 1 <= value['max_tokens'] <= 1700:
        raise ValueError('输出长度超出演示限制。')
    messages = value.get('messages')
    if not isinstance(messages, list) or len(messages) != 2 or [m.get('role') for m in messages if isinstance(m, dict)] != ['system', 'user']:
        raise ValueError('仅允许一条训练要求与一份题目回答。')
    if any(not isinstance(m.get('content'), str) or len(m['content']) > 30000 for m in messages):
        raise ValueError('请求文字不完整或过长。')
    if value.get('thinking') != {'type': 'disabled'} or value.get('response_format') != {'type': 'json_object'}:
        raise ValueError('请使用原网页的固定文字点评配置。')
    return value


def relay_to_zhipu(payload, authorization):
    request = urllib.request.Request(ENDPOINT, data=json.dumps(payload, ensure_ascii=False).encode(), headers={
        'Authorization': authorization, 'Content-Type': 'application/json',
    })
    try:
        with urllib.request.urlopen(request, timeout=65) as response:
            body = response.read(256001)
            if len(body) > 256000:
                return 502, b'{"error":{"code":"response_too_large"}}'
            return response.status, body
    except urllib.error.HTTPError as error:
        # Do not echo upstream bodies that might contain sensitive diagnostics.
        return error.code, json.dumps({'error': {'code': error.code}}).encode()
    except Exception:
        return 502, b'{"error":{"code":"upstream_unavailable"}}'


class DemoServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, page, relay=relay_to_zhipu):
        self.page = Path(page)
        self.relay = relay
        self.request_lock = threading.Lock()
        super().__init__(address, DemoHandler)


class DemoHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def send(self, status, body, content_type='application/json; charset=utf-8'):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.split('?', 1)[0] not in ['/', '/index.html']:
            self.send(404, b'{"error":{"code":"not_found"}}')
            return
        page = self.server.page.read_bytes().replace(b'<head>', b'<head><meta id="shangan-local-helper" content="1">', 1)
        self.send(200, page, 'text/html; charset=utf-8')

    def do_OPTIONS(self):
        # No cross-origin API is exposed, even from the public GitHub page.
        self.send(403, b'{"error":{"code":"same_origin_only"}}')

    def do_POST(self):
        if self.path != '/api/zhipu':
            self.send(404, b'{"error":{"code":"not_found"}}')
            return
        port = self.server.server_address[1]
        allowed_origins = {f'http://localhost:{port}', f'http://127.0.0.1:{port}'}
        if self.headers.get('Origin') and self.headers['Origin'] not in allowed_origins:
            self.send(403, b'{"error":{"code":"same_origin_only"}}')
            return
        authorization = self.headers.get('Authorization', '')
        if not authorization.startswith('Bearer ') or not 20 <= len(authorization[7:]) <= 256:
            self.send(401, b'{"error":{"code":"invalid_key_format"}}')
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 120000 or self.headers.get('Transfer-Encoding') or 'application/json' not in self.headers.get('Content-Type', ''):
                self.send(413, b'{"error":{"code":"payload_limit"}}')
                return
            payload = validate_payload(json.loads(self.rfile.read(length)))
        except (ValueError, TypeError):
            self.send(400, b'{"error":{"code":"invalid_payload"}}')
            return
        if not self.server.request_lock.acquire(blocking=False):
            self.send(429, b'{"error":{"code":"one_request_at_a_time"}}')
            return
        try:
            status, body = self.server.relay(payload, authorization)
            self.send(status, body)
        finally:
            self.server.request_lock.release()


def main():
    parser = argparse.ArgumentParser(description='上岸：仅本机使用的免费模型连接助手')
    parser.add_argument('--port', type=int, default=8416)
    parser.add_argument('--no-open', action='store_true')
    args = parser.parse_args()
    page = Path(__file__).with_name('index.html')
    if not page.exists():
        page = Path(__file__).parent.parent / 'dist/index.html'
    try:
        server = DemoServer(('127.0.0.1', args.port), page)
    except OSError:
        print('无法启动：端口可能已被使用。可用 --port 8417 指定另一个端口。')
        return
    url = f'http://127.0.0.1:{args.port}/'
    print('上岸本机演示已启动：' + url, flush=True)
    print('不保存API Key，不记录回答；关闭本终端即可停止。', flush=True)
    if not args.no_open:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
