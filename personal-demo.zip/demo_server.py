"""Local-only, dependency-free connector for the single-file interview demo.

No API key is stored here. The browser supplies it per request. The connector
relays only the fixed free model to the official provider, without request logs.
"""
import argparse
import errno
import json
import re
from pathlib import Path
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import urllib.error
import urllib.request
import webbrowser
import ssl

ENDPOINT = 'https://open.bigmodel.cn/api/paas/v4/chat/completions'
MODEL = 'glm-4.7-flash'
HELPER_VERSION = 2


def validate_payload(value):
    allowed = {'model', 'messages', 'thinking', 'response_format', 'temperature', 'max_tokens', 'stream'}
    if not isinstance(value, dict) or set(value) - allowed or value.get('model') != MODEL or value.get('stream') is not False:
        raise ValueError('只允许固定的免费文字模型，不允许工具或其他接口。')
    if not isinstance(value.get('max_tokens'), int) or not 1 <= value['max_tokens'] <= 1700:
        raise ValueError('输出长度超出演示限制。')
    messages = value.get('messages')
    if not isinstance(messages, list) or len(messages) != 2 or [m.get('role') for m in messages if isinstance(m, dict)] != ['system', 'user']:
        raise ValueError('仅允许一条训练要求与一份题目回答。')
    if any(not isinstance(m.get('content'), str) or len(m['content']) > 30000 for m in messages):
        raise ValueError('请求文字不完整或过长。')
    if value.get('thinking') != {'type': 'disabled'} or value.get('response_format') != {'type': 'json_object'}:
        raise ValueError('请使用原网页的固定文字点评配置。')
    return value


def relay_to_zhipu(payload, authorization):
    request = urllib.request.Request(ENDPOINT, data=json.dumps(payload, ensure_ascii=False).encode(), headers={
        'Authorization': authorization, 'Content-Type': 'application/json',
    })
    try:
        with urllib.request.urlopen(request, timeout=65) as response:
            body = response.read(256001)
            if len(body) > 256000:
                return 502, b'{"error":{"code":"response_too_large"}}'
            return response.status, body
    except urllib.error.HTTPError as error:
        # Do not echo upstream bodies that might contain sensitive diagnostics.
        code = {401: 'invalid_key', 403: 'model_permission_denied', 404: 'model_or_endpoint_unavailable', 429: 'rate_or_quota_limit'}.get(error.code, 'upstream_error')
        return error.code, json.dumps({'error': {'code': code}}).encode()
    except Exception as error:
        reason = getattr(error, 'reason', error)
        code = 'tls_verification_failed' if isinstance(reason, ssl.SSLCertVerificationError) else 'upstream_timeout' if isinstance(reason, TimeoutError) else 'upstream_unavailable'
        return 502, json.dumps({'error': {'code': code}}).encode()


class DemoServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, page, relay=relay_to_zhipu):
        self.page = Path(page)
        self.relay = relay
        self.request_lock = threading.Lock()
        super().__init__(address, DemoHandler)


class DemoHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def same_origin(self):
        port = self.server.server_address[1]
        hosts = {f'localhost:{port}', f'127.0.0.1:{port}'}
        origins = {f'http://{host}' for host in hosts}
        return self.headers.get('Host', '').lower() in hosts and (not self.headers.get('Origin') or self.headers['Origin'] in origins)

    def send(self, status, body, content_type='application/json; charset=utf-8'):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self.same_origin():
            self.send(403, b'{"error":{"code":"same_origin_only"}}')
            return
        if self.path == '/health':
            self.send(200, json.dumps({'service': 'shangan-personal-demo', 'version': HELPER_VERSION, 'provider': 'zhipu', 'model': MODEL, 'modelVerified': False}).encode())
            return
        asset = self.path.split('?', 1)[0]
        if asset in ['/mascot-welcome.png', '/mascot-support.png', '/mascot-celebrate.png']:
            try:
                self.send(200, (self.server.page.parent / asset[1:]).read_bytes(), 'image/png')
            except OSError:
                self.send(404, b'{"error":{"code":"asset_missing"}}')
            return
        if self.path.split('?', 1)[0] not in ['/', '/index.html']:
            self.send(404, b'{"error":{"code":"not_found"}}')
            return
        page = self.server.page.read_bytes().replace(b'<head>', b'<head><meta id="shangan-local-helper" content="2">', 1)
        self.send(200, page, 'text/html; charset=utf-8')

    def do_OPTIONS(self):
        # No cross-origin API is exposed, even from the public GitHub page.
        self.send(403, b'{"error":{"code":"same_origin_only"}}')

    def do_POST(self):
        if not self.same_origin():
            self.send(403, b'{"error":{"code":"same_origin_only"}}')
            return
        if self.path == '/api/hunyuan':
            # Course pricing and authorization are unverified. Never relay its token.
            self.send(409, b'{"error":{"code":"course_not_verified"}}')
            return
        if self.path != '/api/zhipu':
            self.send(404, b'{"error":{"code":"not_found"}}')
            return
        authorization = self.headers.get('Authorization', '')
        if not authorization.startswith('Bearer ') or not 20 <= len(authorization[7:]) <= 256 or not re.fullmatch(r'[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+', authorization[7:]):
            self.send(401, b'{"error":{"code":"invalid_key_format"}}')
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 120000 or self.headers.get('Transfer-Encoding') or 'application/json' not in self.headers.get('Content-Type', ''):
                self.send(413, b'{"error":{"code":"payload_limit"}}')
                return
            payload = validate_payload(json.loads(self.rfile.read(length)))
        except (ValueError, TypeError):
            self.send(400, b'{"error":{"code":"invalid_payload"}}')
            return
        if not self.server.request_lock.acquire(blocking=False):
            self.send(429, b'{"error":{"code":"one_request_at_a_time"}}')
            return
        try:
            status, body = self.server.relay(payload, authorization)
            self.send(status, body)
        finally:
            self.server.request_lock.release()


def create_server(page, port=8416):
    page = Path(page)
    if not page.is_file():
        raise FileNotFoundError('未找到index.html，请完整解压新版演示包。')
    page.read_bytes()  # Fail before opening the browser when the page is unreadable.
    if not 0 <= port <= 65535:
        raise ValueError('端口需在0～65535之间。')
    candidates = [0] if port == 0 else range(port, min(port + 10, 65536))
    for candidate in candidates:
        try:
            return DemoServer(('127.0.0.1', candidate), page)
        except OSError as error:
            if error.errno != errno.EADDRINUSE:
                raise
    raise OSError('连续10个端口均被占用；请使用 --port 指定其他端口。')


def main():
    parser = argparse.ArgumentParser(description='上岸：仅本机使用的免费模型连接助手')
    parser.add_argument('--port', type=int, default=8416)
    parser.add_argument('--no-open', action='store_true')
    args = parser.parse_args()
    page = Path(__file__).with_name('index.html')
    if not page.exists():
        page = Path(__file__).parent.parent / 'dist/index.html'
    try:
        server = create_server(page, args.port)
    except (OSError, ValueError) as error:
        print('无法启动：' + str(error), flush=True)
        return 1
    url = f'http://127.0.0.1:{server.server_address[1]}/'
    print('上岸本机演示已启动：' + url, flush=True)
    print('助手v2 · 智谱GLM-4.7-Flash；模型尚未验证。请在网页输入新的智谱Key并点击验证。', flush=True)
    print('不保存API Key，不记录回答；关闭本终端即可停止。', flush=True)
    if not args.no_open:
        try:
            opened = webbrowser.open(url)
        except Exception:
            opened = False
        if not opened:
            print('自动打开浏览器失败，请手动打开：' + url, flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
